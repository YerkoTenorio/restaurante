<?php
	
	//configuración de la base de datos por defecto
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "restaurante";

?>