<?php
	
	require("config.php");

	// Crear conexion
	$sqlconnection = new mysqli($servername, $username, $password,$dbname);

	// Revisar conexion
	if ($sqlconnection->connect_error) {
    	die("La conexión ha fallado: " . $sqlconnection->connect_error);
	}
	
?>