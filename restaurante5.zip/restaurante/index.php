<!DOCTYPE html>
<html>
<head>
	<title>Restaurante | Ventas Briones</title>
	<link rel="stylesheet" href="./style.css">
<h1 style="text-align:center;">Restaurante | Ventas Briones</h1>

	<a href="staff" >Empleados</a>
	<a href="admin">Administradores</a>

</head>
<body>

	<!-- partial -->
	<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
	<script src='https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script>

</body>
</html>