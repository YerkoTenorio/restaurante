<?php

	//Añadir un nuevo elemento de menú
	if (isset($_POST['addItem'])) {

		if (!empty($_POST['itemName']) && !empty($_POST['itemPrice']) && !empty($_POST['menuID'])) {
			$itemName = $sqlconnection->real_escape_string($_POST['itemName']);
			$itemPrice = $sqlconnection->real_escape_string($_POST['itemPrice']);
			$menuID = $sqlconnection->real_escape_string($_POST['menuID']);

			$addItemQuery = "INSERT INTO tbl_menuitem (menuID ,menuItemName ,price) VALUES ({$menuID} ,'{$itemName}' ,{$itemPrice})";

			if ($sqlconnection->query($addItemQuery) === TRUE) {
				header("Location: menu.php"); 
				exit();

			} 

			else {
				//handle
				echo "Algo raro";
				echo $sqlconnection->error;
			}
		}

		//No input handle
		else {
			echo "No te quedes con la boca abierta";
		}

	}

	
?>