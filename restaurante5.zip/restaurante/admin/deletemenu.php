<?php

	if (isset($_POST['deletemenu'])) {

		//Borrar el menú
		if (isset($_POST['menuID'])) {
			
			$menuID = $sqlconnection->real_escape_string($_POST['menuID']);

			//eliminar primero todos los elementos de este menú
			$deleteMenuItemQuery = "DELETE FROM tbl_menuitem WHERE menuID = {$menuID}";

			if ($sqlconnection->query($deleteMenuItemQuery) === TRUE) {

				//eliminan el menú después de borrar todos los elementos de este menú
				$deleteMenuQuery = "DELETE FROM tbl_menu WHERE menuID = {$menuID}";

				if ($sqlconnection->query($deleteMenuQuery) === TRUE) {
					header("Location: menu.php"); 
					exit();
					} 
				else {
						//handle
						echo "algo va mal";
						echo $sqlconnection->error;
					}
				} 

			else {
					//handle
					echo "algo va mal";
					echo $sqlconnection->error;
				}
			//echo "<script>alert('{$del_menuID} & {$del_itemID}')</script>";
		}
	}
	

?>