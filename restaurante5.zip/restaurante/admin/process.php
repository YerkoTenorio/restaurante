<?php 
    include("../functions.php");

        //comprobación de la introducción del nombre de usuario y de la contraseña
        if (isset($_POST['username']) && isset($_POST['password'])) {

            //evitar la inyección sql escapando de los caracteres especiales
            $username = $sqlconnection->real_escape_string($_POST['username']);
            $password = $sqlconnection->real_escape_string($_POST['password']);

            //declaración sql
            $sql = "SELECT * FROM tbl_admin WHERE username ='$username' AND password = '$password'";

            if ($result = $sqlconnection->query($sql)) {

                if ($row = $result->fetch_array(MYSQLI_ASSOC)) {
                    
                    $uid = $row['ID'];
                    $username = $row['username'];

                    $_SESSION['uid'] = $uid;
                    $_SESSION['username'] = $username;
                    $_SESSION['user_level'] = "admin";

                    echo "correct";
                }

                else {
                    echo "Nombre de usuario o contraseña incorrectos.";
                }

            }

        }
      
?>